console.log("YouTube to Telegram: Background script loaded!");

let isMonitoring = false;
let lastVideoId = null;

// Initialize on install
chrome.runtime.onInstalled.addListener(() => {
  console.log("Extension installed/updated");
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("Background received message:", message);
  
  if (message.type === "VIDEO_PLAYING") {
    handleVideoUpdate(message.data).then(() => {
      sendResponse({ success: true });
    }).catch((error) => {
      console.error("Error handling video update:", error);
      sendResponse({ success: false, error: error.message });
    });
    return true; // Keep channel open for async
  } 
  
  if (message.type === "START_SESSION") {
    isMonitoring = true;
    chrome.storage.sync.set({ isMonitoring: true });
    console.log("Session started");
    sendResponse({ success: true });
    return true;
  } 
  
  if (message.type === "STOP_SESSION") {
    isMonitoring = false;
    lastVideoId = null;
    chrome.storage.sync.set({ isMonitoring: false });
    console.log("Session stopped");
    sendResponse({ success: true });
    return true;
  }
});

async function handleVideoUpdate(videoData) {
  console.log("Processing video:", videoData);
  
  if (!isMonitoring) {
    console.log("Not monitoring, skipping");
    return;
  }
  
  if (videoData.videoId === lastVideoId) {
    console.log("Same video, skipping");
    return;
  }
  
  lastVideoId = videoData.videoId;
  
  const config = await chrome.storage.sync.get(["botToken", "channelId"]);
  console.log("Config check:", { hasToken: !!config.botToken, hasChannel: !!config.channelId });
  
  if (config.botToken && config.channelId) {
    await sendToTelegram(config.botToken, config.channelId, videoData);
  } else {
    console.error("Missing configuration!");
  }
}

async function sendToTelegram(token, channelId, videoData) {
  const message = `🎵 Now listening to: [${videoData.title}](${videoData.url})`;
  const url = `https://api.telegram.org/bot${token}/sendMessage`;
  
  console.log("Sending to Telegram:", channelId);
  
  try {
    const response = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: channelId,
        text: message,
        parse_mode: "Markdown",
        disable_web_page_preview: false
      })
    });
    
    const result = await response.json();
    console.log("Telegram response:", result);
    
    if (!result.ok) {
      console.error("Telegram error:", result.description);
    } else {
      console.log("✅ Message sent successfully!");
    }
  } catch (error) {
    console.error("Network error:", error);
  }
}
