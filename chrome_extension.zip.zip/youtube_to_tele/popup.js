document.addEventListener("DOMContentLoaded", async () => {
  console.log("Popup loaded");
  
  // Load saved config
  const config = await chrome.storage.sync.get(["botToken", "channelId", "isMonitoring"]);
  
  if (config.botToken) {
    document.getElementById("botToken").value = config.botToken;
  }
  if (config.channelId) {
    document.getElementById("channelId").value = config.channelId;
  }
  
  updateStatus(config.isMonitoring || false);
  
  // Save config
  document.getElementById("saveConfig").addEventListener("click", async () => {
    const botToken = document.getElementById("botToken").value.trim();
    const channelId = document.getElementById("channelId").value.trim();
    
    if (!botToken || !channelId) {
      alert("Please fill in both fields!");
      return;
    }
    
    await chrome.storage.sync.set({ botToken, channelId });
    alert("✅ Configuration saved!");
  });
  
  // Start monitoring
  document.getElementById("startBtn").addEventListener("click", async () => {
    const config = await chrome.storage.sync.get(["botToken", "channelId"]);
    
    if (!config.botToken || !config.channelId) {
      alert("⚠️ Please save your configuration first!");
      return;
    }
    
    await chrome.storage.sync.set({ isMonitoring: true });
    
    try {
      const tabs = await chrome.tabs.query({ url: "*://*.youtube.com/*" });
      
      for (const tab of tabs) {
        try {
          await chrome.tabs.sendMessage(tab.id, { type: "START_MONITORING" });
        } catch (e) {
          console.log("Could not send to tab:", tab.id);
        }
      }
      
      chrome.runtime.sendMessage({ type: "START_SESSION" });
      updateStatus(true);
      
      if (tabs.length === 0) {
        alert("✅ Monitoring started!\n\nOpen YouTube and play a video to test.");
      } else {
        alert("✅ Monitoring started!");
      }
    } catch (error) {
      console.error("Error starting:", error);
      alert("Error: " + error.message);
    }
  });
  
  // Stop monitoring
  document.getElementById("stopBtn").addEventListener("click", async () => {
    await chrome.storage.sync.set({ isMonitoring: false });
    
    try {
      const tabs = await chrome.tabs.query({ url: "*://*.youtube.com/*" });
      
      for (const tab of tabs) {
        try {
          await chrome.tabs.sendMessage(tab.id, { type: "STOP_MONITORING" });
        } catch (e) {
          console.log("Could not send to tab:", tab.id);
        }
      }
      
      chrome.runtime.sendMessage({ type: "STOP_SESSION" });
      updateStatus(false);
      alert("⏹️ Monitoring stopped!");
    } catch (error) {
      console.error("Error stopping:", error);
    }
  });
});

function updateStatus(isActive) {
  const statusEl = document.getElementById("status");
  if (isActive) {
    statusEl.textContent = "🎵 Active - Monitoring YouTube";
    statusEl.className = "active";
  } else {
    statusEl.textContent = "⏹️ Not Running";
    statusEl.className = "inactive";
  }
}