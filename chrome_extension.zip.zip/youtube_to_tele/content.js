console.log("🎵 YouTube to Telegram: Content script loaded!");

let checkInterval = null;
let lastVideoId = null;

function getCurrentVideo() {
  const video = document.querySelector("video");
  if (!video || video.paused) return null;
  
  const videoId = new URLSearchParams(window.location.search).get("v");
  if (!videoId) return null;
  
  const titleElement = document.querySelector("h1.ytd-watch-metadata yt-formatted-string") || 
                       document.querySelector("h1 yt-formatted-string") ||
                       document.querySelector("h1.title");
  
  const title = titleElement ? titleElement.textContent.trim() : "Unknown Video";
  
  return {
    videoId: videoId,
    title: title,
    url: window.location.href
  };
}

function startMonitoring() {
  if (checkInterval) return;
  
  console.log("🎵 Starting monitoring...");
  
  checkInterval = setInterval(() => {
    const videoData = getCurrentVideo();
    if (videoData && videoData.videoId !== lastVideoId) {
      console.log("🎵 New video detected:", videoData.title);
      lastVideoId = videoData.videoId;
      
      chrome.runtime.sendMessage({
        type: "VIDEO_PLAYING",
        data: videoData
      }).catch((error) => {
        console.error("Error sending message:", error);
      });
    }
  }, 5000);
}

function stopMonitoring() {
  if (checkInterval) {
    clearInterval(checkInterval);
    checkInterval = null;
    lastVideoId = null;
    console.log("🎵 Monitoring stopped");
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "START_MONITORING") {
    startMonitoring();
    sendResponse({ success: true });
  } else if (message.type === "STOP_MONITORING") {
    stopMonitoring();
    sendResponse({ success: true });
  }
  return true;
});

// Auto-start if enabled
chrome.storage.sync.get(["isMonitoring"], (result) => {
  if (result.isMonitoring) {
    console.log("🎵 Auto-starting monitoring");
    setTimeout(startMonitoring, 1000);
  }
});