console.log("🎵 YouTube to Telegram: Content script loaded!");

let checkInterval = null;
let lastVideoId = null;
let isMonitoring = false;

function getCurrentVideo() {
  const video = document.querySelector("video");
  if (!video || video.paused) return null;
  
  const videoId = new URLSearchParams(window.location.search).get("v");
  if (!videoId) return null;
  
  const titleElement = document.querySelector("h1.ytd-watch-metadata yt-formatted-string") || 
                       document.querySelector("h1 yt-formatted-string") ||
                       document.querySelector("h1.title");
  
  const title = titleElement ? titleElement.textContent.trim() : "Unknown Video";
  
  return {
    videoId: videoId,
    title: title,
    url: window.location.href
  };
}

function startMonitoring() {
  if (checkInterval) return;
  
  isMonitoring = true;
  console.log("🎵 Starting monitoring...");
  
  checkInterval = setInterval(() => {
    const videoData = getCurrentVideo();
    if (videoData && videoData.videoId !== lastVideoId) {
      console.log("🎵 New video detected:", videoData.title);
      lastVideoId = videoData.videoId;
      
      chrome.runtime.sendMessage({
        type: "VIDEO_PLAYING",
        data: videoData
      }).catch((error) => {
        console.error("Error sending message:", error);
      });
    }
  }, 2000); // Check every 2 seconds for faster detection
}

function stopMonitoring() {
  if (checkInterval) {
    clearInterval(checkInterval);
    checkInterval = null;
    lastVideoId = null;
    isMonitoring = false;
    console.log("🎵 Monitoring stopped");
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  try {
    if (message.type === "START_MONITORING") {
      startMonitoring();
      sendResponse({ success: true });
    } else if (message.type === "STOP_MONITORING") {
      stopMonitoring();
      sendResponse({ success: true });
    }
  } catch (error) {
    console.error("Error in message listener:", error);
    sendResponse({ success: false, error: error.message });
  }
  return true;
});

// Check monitoring status and auto-start if needed
function checkAndAutoStart() {
  chrome.storage.sync.get(["isMonitoring"], (result) => {
    if (result.isMonitoring && !isMonitoring) {
      console.log("🎵 Auto-starting monitoring on page");
      startMonitoring();
    }
  });
}

// Auto-start if enabled
checkAndAutoStart();

// Also check when page visibility changes
document.addEventListener("visibilitychange", () => {
  if (!document.hidden && !isMonitoring) {
    console.log("🎵 Page became visible, checking if should resume monitoring");
    checkAndAutoStart();
  }
});

// Check every 5 seconds if monitoring should be on
setInterval(() => {
  chrome.storage.sync.get(["isMonitoring"], (result) => {
    if (result.isMonitoring && !isMonitoring) {
      console.log("🎵 Resuming monitoring");
      startMonitoring();
    }
  });
}, 5000);