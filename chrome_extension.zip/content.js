console.log("🎵 YouTube to Telegram: Content script loaded!");

let checkInterval = null;
let lastVideoId = null;
let isMonitoring = false;

function getCurrentVideo() {
  try {
    // Get video element
    const video = document.querySelector("video");
    if (!video) {
      return null;
    }
    
    if (video.paused) {
      return null;
    }
    
    // Get video ID from URL
    const urlParams = new URLSearchParams(window.location.search);
    const videoId = urlParams.get("v");
    
    if (!videoId) {
      return null;
    }
    
    // Get title - try multiple selectors
    let title = "Unknown Video";
    const titleSelectors = [
      "h1 yt-formatted-string",
      "h1.title yt-formatted-string",
      "yt-formatted-string.style-scope.ytd-video-primary-info-renderer",
      "span#eow-title",
      "h1[class*='title']"
    ];
    
    for (const selector of titleSelectors) {
      const el = document.querySelector(selector);
      if (el && el.textContent.trim()) {
        title = el.textContent.trim();
        break;
      }
    }
    
    return {
      videoId: videoId,
      title: title,
      url: window.location.href
    };
  } catch (error) {
    return null;
  }
}

function startMonitoring() {
  if (checkInterval) {
    return;
  }
  
  isMonitoring = true;
  console.log("🎵 Starting monitoring...");
  
  checkInterval = setInterval(() => {
    try {
      const videoData = getCurrentVideo();
      
      if (videoData && videoData.videoId !== lastVideoId) {
        console.log("🎵 New video detected:", videoData.title);
        lastVideoId = videoData.videoId;
        
        // Send to background script with error handling
        try {
          chrome.runtime.sendMessage({
            type: "VIDEO_PLAYING",
            data: videoData
          }, (response) => {
            if (response) {
              console.log("Message sent successfully");
            }
          });
        } catch (sendError) {
          console.log("Could not send message - extension may have reloaded");
        }
      }
    } catch (error) {
      // Silently fail on interval
    }
  }, 3000);
}

function stopMonitoring() {
  if (checkInterval) {
    clearInterval(checkInterval);
    checkInterval = null;
    lastVideoId = null;
    isMonitoring = false;
    console.log("🎵 Monitoring stopped");
  }
}

// Message listener with error handling
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  try {
    if (message.type === "START_MONITORING") {
      startMonitoring();
      sendResponse({ success: true });
    } else if (message.type === "STOP_MONITORING") {
      stopMonitoring();
      sendResponse({ success: true });
    }
  } catch (error) {
    console.error("Message handler error:", error);
  }
  
  return true;
});

// Try to get monitoring status once
try {
  chrome.storage.local.get(["isMonitoring"], (result) => {
    try {
      if (result && result.isMonitoring) {
        console.log("Auto-starting monitoring");
        setTimeout(startMonitoring, 500);
      }
    } catch (e) {
      console.log("Could not auto-start");
    }
  });
} catch (e) {
  console.log("Storage access not available");
}