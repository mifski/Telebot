console.log("🎵 YouTube to Telegram: Content script loaded!");

let checkInterval = null;
let lastVideoId = null;
let isMonitoring = false;

function getCurrentVideo() {
  try {
    // Get video element
    const video = document.querySelector("video");
    if (!video) {
      console.log("No video element found");
      return null;
    }
    
    if (video.paused) {
      console.log("Video is paused");
      return null;
    }
    
    // Get video ID from URL
    const urlParams = new URLSearchParams(window.location.search);
    const videoId = urlParams.get("v");
    
    if (!videoId) {
      console.log("No video ID in URL");
      return null;
    }
    
    // Get title - try multiple selectors
    let title = "Unknown Video";
    const titleSelectors = [
      "h1.title yt-formatted-string",
      "h1 yt-formatted-string",
      "yt-formatted-string.title",
      "h1 yt-formatted-string a",
      "[aria-label*='Watch']"
    ];
    
    for (const selector of titleSelectors) {
      const el = document.querySelector(selector);
      if (el && el.textContent.trim()) {
        title = el.textContent.trim();
        break;
      }
    }
    
    return {
      videoId: videoId,
      title: title,
      url: window.location.href
    };
  } catch (error) {
    console.error("Error getting video:", error);
    return null;
  }
}

function startMonitoring() {
  if (checkInterval) {
    console.log("Already monitoring");
    return;
  }
  
  isMonitoring = true;
  console.log("🎵 Starting monitoring...");
  
  checkInterval = setInterval(() => {
    try {
      const videoData = getCurrentVideo();
      
      if (videoData && videoData.videoId !== lastVideoId) {
        console.log("🎵 New video detected:", videoData.title);
        lastVideoId = videoData.videoId;
        
        // Send to background script
        chrome.runtime.sendMessage({
          type: "VIDEO_PLAYING",
          data: videoData
        }, (response) => {
          if (chrome.runtime.lastError) {
            console.error("Send error:", chrome.runtime.lastError);
          } else {
            console.log("Message sent to background");
          }
        });
      }
    } catch (error) {
      console.error("Error in monitoring interval:", error);
    }
  }, 3000); // Check every 3 seconds
}

function stopMonitoring() {
  if (checkInterval) {
    clearInterval(checkInterval);
    checkInterval = null;
    lastVideoId = null;
    isMonitoring = false;
    console.log("🎵 Monitoring stopped");
  }
}

// Message listener
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("Content script received:", message.type);
  
  try {
    if (message.type === "START_MONITORING") {
      startMonitoring();
      sendResponse({ success: true });
    } else if (message.type === "STOP_MONITORING") {
      stopMonitoring();
      sendResponse({ success: true });
    }
  } catch (error) {
    console.error("Message handler error:", error);
    sendResponse({ success: false, error: error.message });
  }
  
  return true;
});

// Check if monitoring should auto-start
console.log("Checking if should auto-start monitoring...");
chrome.storage.sync.get(["isMonitoring"], (result) => {
  console.log("Storage check result:", result);
  if (result.isMonitoring) {
    console.log("Auto-starting monitoring");
    setTimeout(startMonitoring, 500);
  }
});

// Resume monitoring if page visibility changes
document.addEventListener("visibilitychange", () => {
  if (!document.hidden && isMonitoring && !checkInterval) {
    console.log("Page became visible, resuming monitoring");
    startMonitoring();
  }
});