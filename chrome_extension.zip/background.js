console.log("YouTube to Telegram: Background script loaded!");

let isMonitoring = false;
let lastVideoId = null;

// Initialize on install
chrome.runtime.onInstalled.addListener(() => {
  console.log("Extension installed/updated");
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("Background received message:", message);
  
  if (message.type === "VIDEO_PLAYING") {
    handleVideoUpdate(message.data).then(() => {
      sendResponse({ success: true });
    }).catch((error) => {
      console.error("Error handling video update:", error);
      sendResponse({ success: false, error: error.message });
    });
    return true; // Keep channel open for async
  } 
  
  if (message.type === "START_SESSION") {
    isMonitoring = true;
    chrome.storage.sync.set({ isMonitoring: true });
    console.log("Session started");
    sendResponse({ success: true });
    return true;
  } 
  
  if (message.type === "STOP_SESSION") {
    isMonitoring = false;
    lastVideoId = null;
    chrome.storage.sync.set({ isMonitoring: false });
    console.log("Session stopped");
    sendResponse({ success: true });
    return true;
  }
});

async function handleVideoUpdate(videoData) {
  console.log("Processing video:", videoData);
  
  if (!isMonitoring) {
    console.log("Not monitoring, skipping");
    return;
  }
  
  if (videoData.videoId === lastVideoId) {
    console.log("Same video, skipping");
    return;
  }
  
  lastVideoId = videoData.videoId;
  
  const config = await chrome.storage.sync.get(["channelId", "userId"]);
  console.log("Config check:", { hasChannel: !!config.channelId, hasUserId: !!config.userId });
  
  if (config.channelId && config.userId) {
    await sendToTelegramBot(config.channelId, config.userId, videoData);
  } else {
    console.error("Missing configuration!");
  }
}

async function sendToTelegramBot(channelId, userId, videoData) {
  console.log("Sending video to bot server:", { channelId, userId, title: videoData.title });
  
  const botServerUrl = "http://localhost:5000"; // Update to your deployed bot server URL
  
  try {
    // First, get user's custom config
    let message = `🎵 Now listening to: [${videoData.title}](${videoData.url})`;
    
    try {
      const configResponse = await fetch(`${botServerUrl}/api/config/${userId}`);
      if (configResponse.ok) {
        const configData = await configResponse.json();
        if (configData.success && configData.config) {
          const emoji = configData.config.emoji || "🎵";
          const format = configData.config.message_format || "now listening to";
          message = `${emoji} ${format}: [${videoData.title}](${videoData.url})`;
          console.log("✅ Loaded custom format:", message);
        }
      }
    } catch (e) {
      console.log("Could not fetch custom format, using default:", e.message);
    }
    
    // Send to bot server to post to Telegram
    const response = await fetch(`${botServerUrl}/api/send-video`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        channel_id: channelId,
        user_id: userId,
        title: videoData.title,
        url: videoData.url,
        message: message
      })
    });
    
    const result = await response.json();
    console.log("Bot server response:", result);
    
    if (result.success) {
      console.log("✅ Video posted successfully!");
    } else {
      console.error("Bot server error:", result.error);
    }
  } catch (error) {
    console.error("Error sending to bot server:", error);
  }
}
