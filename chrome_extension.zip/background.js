const botServerUrl = "http://localhost:5000";
let lastVideoId = null;

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  try {
    if (message.type === "VIDEO_PLAYING") {
      handleVideoUpdate(message.data);
    } else if (message.type === "START_SESSION") {
      console.log("Session started");
    } else if (message.type === "STOP_SESSION") {
      lastVideoId = null;
      console.log("Session stopped");
    }
  } catch (error) {
    console.error("Message handler error:", error);
  }
  
  sendResponse({ received: true });
  return false;
});

async function handleVideoUpdate(videoData) {
  try {
    if (videoData.videoId === lastVideoId) {
      return;
    }
    lastVideoId = videoData.videoId;
    
    const config = await chrome.storage.local.get(["channelId", "userId"]);
    
    if (!config.channelId || !config.userId) {
      console.warn("Config not set");
      return;
    }
    
    console.log("Processing video:", videoData.title);
    await sendToTelegramBot(config, videoData);
  } catch (error) {
    console.error("Error handling video:", error);
  }
}

async function sendToTelegramBot(config, videoData) {
  try {
    let message = `🎵 Now listening to: [${videoData.title}](${videoData.url})`;
    
    try {
      const configResponse = await fetch(`${botServerUrl}/api/config/${config.userId}`);
      if (configResponse.ok) {
        const configData = await configResponse.json();
        if (configData.success && configData.config) {
          const emoji = configData.config.emoji || "🎵";
          const format = configData.config.message_format || "now listening to";
          message = `${emoji} ${format}: [${videoData.title}](${videoData.url})`;
        }
      }
    } catch (e) {
      console.log("Using default format");
    }
    
    const response = await fetch(`${botServerUrl}/api/send-video`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        channel_id: config.channelId,
        user_id: config.userId,
        title: videoData.title,
        url: videoData.url,
        message: message
      })
    });
    
    if (response.ok) {
      console.log("✅ Video sent to Telegram");
    } else {
      console.error("❌ Failed to send video");
    }
  } catch (error) {
    console.error("Error sending video:", error.message);
  }
}