console.log("YouTube to Telegram: Background script loaded!");

let isMonitoring = false;
let lastVideoId = null;

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  console.log("Background received message:", message.type);
  
  if (message.type === "VIDEO_PLAYING") {
    console.log("Processing video:", message.data.title);
    handleVideoUpdate(message.data);
    sendResponse({ success: true });
    return true;
  }
  
  if (message.type === "START_SESSION") {
    isMonitoring = true;
    console.log("Session started");
    sendResponse({ success: true });
    return true;
  }
  
  if (message.type === "STOP_SESSION") {
    isMonitoring = false;
    lastVideoId = null;
    console.log("Session stopped");
    sendResponse({ success: true });
    return true;
  }
});

async function handleVideoUpdate(videoData) {
  console.log("Handling video update:", videoData);
  
  try {
    const config = await chrome.storage.sync.get(["channelId", "userId"]);
    console.log("Config loaded:", { hasChannel: !!config.channelId, hasUser: !!config.userId });
    
    if (!config.channelId || !config.userId) {
      console.error("Missing config - channel:", config.channelId, "user:", config.userId);
      return;
    }
    
    if (videoData.videoId === lastVideoId) {
      console.log("Same video, skipping");
      return;
    }
    
    lastVideoId = videoData.videoId;
    
    await sendToTelegramBot(config.channelId, config.userId, videoData);
    
  } catch (error) {
    console.error("Error in handleVideoUpdate:", error);
  }
}

async function sendToTelegramBot(channelId, userId, videoData) {
  const botServerUrl = "http://localhost:5000";
  
  console.log("Sending to bot server:", {
    url: botServerUrl,
    channelId: channelId,
    userId: userId,
    title: videoData.title
  });
  
  try {
    // Get custom format
    let message = `🎵 Now listening to: [${videoData.title}](${videoData.url})`;
    
    try {
      const configResponse = await fetch(`${botServerUrl}/api/config/${userId}`);
      if (configResponse.ok) {
        const configData = await configResponse.json();
        if (configData.success && configData.config) {
          const emoji = configData.config.emoji || "🎵";
          const format = configData.config.message_format || "now listening to";
          message = `${emoji} ${format}: [${videoData.title}](${videoData.url})`;
          console.log("Custom format loaded:", message);
        }
      }
    } catch (e) {
      console.log("Using default format - config fetch failed:", e.message);
    }
    
    // Send to bot server
    console.log("Calling POST /api/send-video...");
    const response = await fetch(`${botServerUrl}/api/send-video`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        channel_id: channelId,
        user_id: userId,
        title: videoData.title,
        url: videoData.url,
        message: message
      })
    });
    
    const result = await response.json();
    console.log("Bot server response:", result);
    
    if (result.success) {
      console.log("✅ SUCCESS - Video posted!");
    } else {
      console.error("❌ FAILED -", result.error);
    }
    
  } catch (error) {
    console.error("❌ Error sending to bot server:", error.message);
    console.error("Make sure bot server is running at:", "http://localhost:5000");
  }
}