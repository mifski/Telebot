document.addEventListener("DOMContentLoaded", async () => {
  console.log("Popup loaded");
  
  // Load saved config
  const config = await chrome.storage.local.get(["channelId", "userId", "isMonitoring"]);
  
  if (config.channelId) {
    document.getElementById("channelId").value = config.channelId;
  }
  if (config.userId) {
    document.getElementById("userId").value = config.userId;
  }
  
  updateStatus(config.isMonitoring || false);
  
  // Save config
  document.getElementById("saveConfig").addEventListener("click", async () => {
    const channelId = document.getElementById("channelId").value.trim();
    const userId = document.getElementById("userId").value.trim();
    
    if (!channelId || !userId) {
      alert("Please fill in both Channel ID and User ID!");
      return;
    }
    
    await chrome.storage.local.set({ channelId, userId });
    alert("✅ Configuration saved!");
  });
  
  // Start monitoring
  document.getElementById("startBtn").addEventListener("click", async () => {
    const config = await chrome.storage.local.get(["channelId", "userId"]);
    
    if (!config.channelId || !config.userId) {
      alert("⚠️ Please save your configuration first!");
      return;
    }
    
    await chrome.storage.local.set({ isMonitoring: true });
    
    try {
      const tabs = await chrome.tabs.query({ url: "*://*.youtube.com/*" });
      
      for (const tab of tabs) {
        try {
          await chrome.tabs.sendMessage(tab.id, { type: "START_MONITORING" });
        } catch (e) {
          console.log("Could not send to tab:", tab.id);
        }
      }
      
      chrome.runtime.sendMessage({ type: "START_SESSION" });
      updateStatus(true);
      
      if (tabs.length === 0) {
        alert("✅ Monitoring started!\n\nOpen YouTube and play a video to test.");
      } else {
        alert("✅ Monitoring started!");
      }
    } catch (error) {
      console.error("Error starting:", error);
      alert("Error: " + error.message);
    }
  });
  
  // Stop monitoring
  document.getElementById("stopBtn").addEventListener("click", async () => {
    await chrome.storage.local.set({ isMonitoring: false });
    
    try {
      const tabs = await chrome.tabs.query({ url: "*://*.youtube.com/*" });
      
      for (const tab of tabs) {
        try {
          await chrome.tabs.sendMessage(tab.id, { type: "STOP_MONITORING" });
        } catch (e) {
          console.log("Could not send to tab:", tab.id);
        }
      }
      
      chrome.runtime.sendMessage({ type: "STOP_SESSION" });
      updateStatus(false);
      alert("⏹️ Monitoring stopped!");
    } catch (error) {
      console.error("Error stopping:", error);
    }
  });
});

function updateStatus(isActive) {
  const statusEl = document.getElementById("status");
  if (isActive) {
    statusEl.textContent = "🎵 Active - Monitoring YouTube";
    statusEl.className = "active";
  } else {
    statusEl.textContent = "⏹️ Not Running";
    statusEl.className = "inactive";
  }
}